package com.testcases;


import com.libraries.LIB_Common;
import com.libraries.LIB_UserAPI;
import com.utils.ExcelUtils;
import org.testng.annotations.*;

import java.util.Map;


public class TS_001 {

    LIB_Common lIB_Common;
    LIB_UserAPI lIB_UserAPI;

    @BeforeTest
    public void get() {
         lIB_Common = new LIB_Common();
         lIB_UserAPI = new LIB_UserAPI();
    }


    @Test(dataProvider = "loginData")
    public void tc_login1(Map<String, String> testData){
        lIB_UserAPI.bc_login();
        lIB_Common.bc_login(testData.get("Url"),testData.get("Username"), testData.get("Password"));
        lIB_Common.bc_logOut();
    }


    @AfterTest
    public void closeBrowser() {
        lIB_Common.closeBrowser();

    }


    @DataProvider(name = "loginData")
    public Object[][] getData() {
//        return ExcelUtils.getExcelDataAsMap("LoginData", "tc_001");
        return ExcelUtils.getExcelDataAsMapForIteration( "loginData" );
    }



}