package com.libraries;


import com.base.CommandsAPI;
import io.restassured.response.Response;
import java.util.HashMap;
import java.util.Map;

public class LIB_UserAPI {

    CommandsAPI api = new CommandsAPI();

    public void bc_login() {
        api.startBusinessComponent("bc_createUser");

        Map<String, String> form = new HashMap<>();
        form.put("username", "Admin");
        form.put("password", "admin123");

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/x-www-form-urlencoded");

        Response response = api.postForm( "https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate",
                form
        );

        api.verifyStatusCode(response, 302);

        api.endBusinessComponent("bc_createUser");
    }
}