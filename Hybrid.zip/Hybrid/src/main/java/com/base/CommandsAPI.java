package com.base;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.utils.ExtentManager;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.util.Map;


import java.util.Map;

public class CommandsAPI {

    private static final Logger logger = LogManager.getLogger(CommandsAPI.class);

    // ThreadSafe Storage for Authentication
    private static ThreadLocal<String> threadBearerToken = new ThreadLocal<>();
    private static ThreadLocal<String[]> threadBasicAuth = new ThreadLocal<>();
    ExtentTest testLog = ExtentManager.getTest();

    // =======================================================
    //  AUTHENTICATION METHODS
    // =======================================================

    /**
     * Set Bearer Token for all subsequent requests in this thread.
     */
    public void setBearerToken(String token) {
        threadBearerToken.set(token);
        logger.info("Bearer Token set for current thread.");
    }

    /**
     * Set Basic Auth for all subsequent requests in this thread.
     */
    public void setBasicAuth(String username, String password) {
        threadBasicAuth.set(new String[]{username, password});
        logger.info("Basic Auth set for current thread.");
    }

    /**
     * Clear all auth headers (Call this after test or logout).
     */
    public void resetAuth() {
        threadBearerToken.remove();
        threadBasicAuth.remove();
        logger.info("Authentication cleared.");
    }

    // =======================================================
    //  REQUEST METHODS
    // =======================================================

    public Response postForm(String endpoint, Map<String, String> formData) {
        return sendRequest("POST_FORM", endpoint, formData, null);
    }

    public Response get(String endpoint) {
        return sendRequest("GET", endpoint, null, null);
    }

    public Response post(String endpoint, Object body) {
        return sendRequest("POST", endpoint, body, null);
    }

    public Response put(String endpoint, Object body) {
        return sendRequest("PUT", endpoint, body, null);
    }

    public Response delete(String endpoint) {
        return sendRequest("DELETE", endpoint, null, null);
    }

    // =======================================================
    //  CORE ENGINE
    // =======================================================

    private Response sendRequest(String method,
                                 String endpoint,
                                 Object body,
                                 Map<String, String> headers) {

        RequestSpecification request = RestAssured.given();

        // 1. Add Headers
        if (headers != null) {
            request.headers(headers);
        }

        // 2. Handle Body Types
        if (method.equalsIgnoreCase("POST_FORM")
                    || method.equalsIgnoreCase("PUT_FORM")) {

            request.contentType("application/x-www-form-urlencoded");
            request.formParams((Map<String, String>) body);

        } else if (body != null) {

            // JSON body (default)
            request.contentType(ContentType.JSON);
            request.body(body);
        }

        // 3. Execute Request
        Response response;

        switch (method.toUpperCase()) {

            case "GET" -> response = request.get(endpoint);
            case "POST" -> response = request.post(endpoint);
            case "PUT" -> response = request.put(endpoint);
            case "DELETE" -> response = request.delete(endpoint);
            case "PATCH" -> response = request.patch(endpoint);

            case "POST_FORM" -> response = request.post(endpoint);
            case "PUT_FORM" -> response = request.put(endpoint);

            default -> throw new IllegalArgumentException("Invalid API Method: " + method);
        }

        return response;
    }


    // =======================================================
    //  HELPER METHODS
    // =======================================================

    /**
     * Extracts a String value from the JSON Response using JSONPath.
     * Example: extractString(response, "token") or "data.id"
     */
    public String extractString(Response response, String jsonPath) {
        try {
            String value = response.jsonPath().getString(jsonPath);
            logger.info("Extracted '" + jsonPath + "': " + value);
            return value;
        } catch (Exception e) {
            throw new RuntimeException("Failed to extract '" + jsonPath + "' from response.");
        }
    }

    public void verifyStatusCode(Response response, int expectedCode) {
        int actual = response.getStatusCode();
        if (actual == expectedCode) {
            if (testLog != null) testLog.pass("Status Verified: " + expectedCode);
            logger.info("Status Verified: " + expectedCode);
        } else {
            ExtentManager.getTest().fail("Status Mismatch. Exp: " + expectedCode + ", Act: " + actual);
            throw new AssertionError("Status Mismatch");
        }
    }

    public void startBusinessComponent(String bcName) {
        // Same as your existing code
        if (ExtentManager.getTest() != null)
            ExtentManager.getTest().info("<b style='color:teal'>API BC Started: " + bcName + "</b>");
    }

    public void endBusinessComponent(String bcName) {
        // Same as your existing code
        if (ExtentManager.getTest() != null)
            ExtentManager.getTest().info("<b style='color:teal'>API BC Ended: " + bcName + "</b>");
    }
}